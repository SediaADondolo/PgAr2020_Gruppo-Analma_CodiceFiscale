
public class MainTest {

	public static void main(String[] args) {
		
		
		CodeGenerator test=new CodeGenerator();
		
		System.out.print(test.surname("CASELLA"));
		System.out.print(test.name("MATTEO"));

	}

}
